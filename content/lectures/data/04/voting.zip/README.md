# Voting Data for Lecture 4

Original Source:  
https://github.com/datadesk/california-2016-election-precinct-maps/tree/master/065-riverside-county

